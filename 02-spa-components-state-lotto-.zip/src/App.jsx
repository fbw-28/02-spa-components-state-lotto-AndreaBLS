import React from "react";
import LuckyNumbers from "./LuckyNumbers";

function App() {
  return (
    <h1>Lotto 6/49</h1>
    <p>Generating lucky </p>
  );
}

export default App;
