
import React from "react"
import App from "./App.jsx"
import reactDOM from "react-dom"
import "./app.css"
import Luckynumbers from "./LuckyNumbers"

reactDOM.render(<App/>,document.getElementById("root"))