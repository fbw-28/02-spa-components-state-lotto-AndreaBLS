import React from "react";

export default function LuckyNumbers() {
  return <div></div>;
}
